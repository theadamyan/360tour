var APP_DATA = {
  "scenes": [
    {
      "id": "0--1",
      "name": "Панорама №1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1920,
      "initialViewParameters": {
        "yaw": 1.2232204770740704,
        "pitch": 0.18806307690909918,
        "fov": 1.3715802068843215
      },
      "linkHotspots": [
        {
          "yaw": -0.40752716137086864,
          "pitch": 0.16590629951278046,
          "rotation": 0,
          "target": "6--7"
        },
        {
          "yaw": 1.2215544886200007,
          "pitch": 0.5371961954402895,
          "rotation": 0,
          "target": "1--2"
        },
        {
          "yaw": 1.2337381369548197,
          "pitch": 0.3128875848732733,
          "rotation": 0,
          "target": "2--3"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1--2",
      "name": "Панорама №2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1920,
      "initialViewParameters": {
        "yaw": -0.5330979797902096,
        "pitch": 0.5676937926030572,
        "fov": 1.3715802068843215
      },
      "linkHotspots": [
        {
          "yaw": -1.7400914805215724,
          "pitch": 0.7968645791774911,
          "rotation": 0,
          "target": "2--3"
        },
        {
          "yaw": -0.022425210647957883,
          "pitch": 0.8085729575241007,
          "rotation": 0,
          "target": "3--4"
        },
        {
          "yaw": -0.20814580021791684,
          "pitch": 0.44056525429700955,
          "rotation": 0,
          "target": "4--5"
        },
        {
          "yaw": 3.0519341519959173,
          "pitch": 0.49219613169687193,
          "rotation": 0,
          "target": "0--1"
        },
        {
          "yaw": -2.9551800574763174,
          "pitch": 0.06789801337235701,
          "rotation": 0,
          "target": "6--7"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2--3",
      "name": "Панорама №3",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1920,
      "initialViewParameters": {
        "yaw": 0.5219808379891138,
        "pitch": 0.6259162528294144,
        "fov": 1.3715802068843215
      },
      "linkHotspots": [
        {
          "yaw": 1.7270144412544726,
          "pitch": 0.6619079560760479,
          "rotation": 0,
          "target": "1--2"
        },
        {
          "yaw": 0.9063121375189063,
          "pitch": 0.5574238561747578,
          "rotation": 0,
          "target": "3--4"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3--4",
      "name": "Панорама №4",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1920,
      "initialViewParameters": {
        "yaw": -1.0443818910399294,
        "pitch": 0.6054356797068294,
        "fov": 1.3715802068843215
      },
      "linkHotspots": [
        {
          "yaw": -0.42256503163118,
          "pitch": 0.6821585203263894,
          "rotation": 0,
          "target": "4--5"
        },
        {
          "yaw": -2.5537967890137416,
          "pitch": 0.5584530701750694,
          "rotation": 0,
          "target": "2--3"
        },
        {
          "yaw": 2.912567836920932,
          "pitch": 0.3420201163470704,
          "rotation": 0,
          "target": "0--1"
        },
        {
          "yaw": -0.9705317753352745,
          "pitch": 0.5432184844593095,
          "rotation": 0,
          "target": "5--6"
        },
        {
          "yaw": 2.8903394371678477,
          "pitch": 0.7003442648674962,
          "rotation": 0,
          "target": "1--2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4--5",
      "name": "Панорама №5",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1920,
      "initialViewParameters": {
        "yaw": 2.9424495247783256,
        "pitch": 0.4863282862766347,
        "fov": 1.3715802068843215
      },
      "linkHotspots": [
        {
          "yaw": 2.289575060096081,
          "pitch": 0.5947904890117677,
          "rotation": 0,
          "target": "3--4"
        },
        {
          "yaw": 2.501021933036455,
          "pitch": 0.21496278352830167,
          "rotation": 0,
          "target": "0--1"
        },
        {
          "yaw": 2.4263839010920645,
          "pitch": 0.3795257094845219,
          "rotation": 0,
          "target": "1--2"
        },
        {
          "yaw": -2.1802984779613226,
          "pitch": 0.8946008454796406,
          "rotation": 0,
          "target": "5--6"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "5--6",
      "name": "Панорама №6",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1920,
      "initialViewParameters": {
        "yaw": -2.2464083101844903,
        "pitch": 0.4001075830846581,
        "fov": 1.3715802068843215
      },
      "linkHotspots": [
        {
          "yaw": 2.8217226147695715,
          "pitch": 0.7836238138031213,
          "rotation": 0,
          "target": "4--5"
        },
        {
          "yaw": -2.6131334647506463,
          "pitch": 0.43893010907253505,
          "rotation": 0,
          "target": "3--4"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "6--7",
      "name": "Панорама №7",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1920,
      "initialViewParameters": {
        "yaw": -2.3557103006704274,
        "pitch": 0.543543374971053,
        "fov": 1.3715802068843215
      },
      "linkHotspots": [
        {
          "yaw": 0.1248420705800033,
          "pitch": 0.12600534866107793,
          "rotation": 0,
          "target": "0--1"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Эко",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
